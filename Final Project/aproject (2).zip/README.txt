README

Course: cs400
Semester: Summer 2020
Project name: Calculate milk weight
Student Name: Zhan Yu

email: zyu@wisc.edu

Other notes or comments to the grader:
This project can be operated by entering valid and proper data in the text fields and then press the "Get" butttons above the tables. 
The contents of those tables can be milk weight for each farm or all farms in any valid period. However, please reopen the GUI if you
want to press the same "Get" button twice. :) 