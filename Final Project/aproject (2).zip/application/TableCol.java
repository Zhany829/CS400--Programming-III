package application;

import javafx.beans.property.SimpleStringProperty;

public class TableCol {
	 private final SimpleStringProperty ID;
     private final SimpleStringProperty totalWeight;

     TableCol(String ID, String totalWeight) {
         this.ID = new SimpleStringProperty(ID);        
         this.totalWeight = new SimpleStringProperty(totalWeight);
     }

     
     public String getID() {
         return ID.get();
     }

     public void setID(String ID) {
         this.ID.set(ID);
     }

     public String getTotalWeight() {
         return totalWeight.get();
     }

     public void setTotalweight(String totalWeight) {
         this.totalWeight.set(totalWeight);
     }
}
