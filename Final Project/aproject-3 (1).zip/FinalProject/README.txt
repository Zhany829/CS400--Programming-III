README

Course: cs400
Semester: Summer 2020
Project name: FinalProject
Student Name: Zhan Yu

email: zyu293@wisc.edu

Other notes or comments to the grader:
This project can be operated by entering valid and proper data in the text fields and then press the "Get" butttons above the tables. 
The contents of those tables can be milk weight for each farm or all farms in any valid period. However, please reopen the GUI if you
want to input a different data and press the same "Get" button twice. For loading the files, please input the path to the folder that 
has the files needed for different reports or calculation. For example, if you want to load the file 2020-1.csv. You can input the path
to the folder that only has this file, like C:\eclipse 2020.6\FinalProject\application.(You do not need to add quatation mark for the path).
If you want to load one year information, your folder needs to have 12 files that contains each month's data, otherwise you will not get 
the right result. Finally, make sure you reopen the GUI if you want to load different files.