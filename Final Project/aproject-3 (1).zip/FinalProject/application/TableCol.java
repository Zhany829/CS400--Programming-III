package application;

import javafx.beans.property.SimpleStringProperty;
////////////////FILE HEADER (INCLUDE IN EVERY FILE) //////////////////////////
//
//Title: FinalProject
//Files: GUIAndCalculation.java, TableCol.java
//Author: ZHAN YU
//Email: zyu293@wisc.edu
//Course: SU20 CS 400 002
//Deadline: 8/08/2020
//Description: This class aims to create tables for displaying results
///////////////////////// ALWAYS CREDIT OUTSIDE HELP //////////////////////////
//
//Students who get help from sources other than their partner and the course
//staff must fully acknowledge and credit those sources here. If you did not
//receive any help of any kind from outside sources, explicitly indicate NONE
//next to each of the labels below.
//
//Persons: NONE
//Online Sources: 
//
///////////////////////////////////////////////////////////////////////////////
/***
 * This class aims to create tables for displaying results
 * @author Zhan Yu
 *
 */
public class TableCol {
	 private final SimpleStringProperty ID;
     private final SimpleStringProperty totalWeight;

     TableCol(String ID, String totalWeight) {
         this.ID = new SimpleStringProperty(ID);        
         this.totalWeight = new SimpleStringProperty(totalWeight);
     }

     
     public String getID() {
         return ID.get();
     }

     public void setID(String ID) {
         this.ID.set(ID);
     }

     public String getTotalWeight() {
         return totalWeight.get();
     }

     public void setTotalweight(String totalWeight) {
         this.totalWeight.set(totalWeight);
     }
}
